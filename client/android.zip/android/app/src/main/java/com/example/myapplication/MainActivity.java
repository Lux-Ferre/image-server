import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.*;
import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final String UPLOAD_URL = "https://img.luxferre.dev/upload";
    private static final String API_KEY = "secret_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if the activity was started with a share intent
        Intent intent = getIntent();
        if (Intent.ACTION_SEND.equals(intent.getAction()) && intent.getType() != null && intent.getType().startsWith("image/")) {
            handleSendImage(intent); // Handle the received image
        } else {
            finish(); // Close the app if not started with the expected intent
        }
    }

    private void handleSendImage(Intent intent) {
        Uri imageUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        if (imageUri != null) {
            uploadScreenshot(imageUri);
        } else {
            finish(); // Close the app if no image is received
        }
    }

    private void uploadScreenshot(Uri imageUri) {
        try {
            // Generate the new file name
            String fileName = generateFileName();

            // Get the image input stream
            InputStream inputStream = getContentResolver().openInputStream(imageUri);

            // Convert the input stream to byte array
            byte[] imageData = IOUtils.toByteArray(inputStream);

            // Use OkHttp to upload the image
            OkHttpClient client = new OkHttpClient();

            // Create the request body with the image and the headers
            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("file", fileName, RequestBody.create(imageData))
                    .build();

            // Create the request
            Request request = new Request.Builder()
                    .url(UPLOAD_URL)
                    .post(requestBody)
                    .addHeader("X-API-KEY", API_KEY)
                    .build();

            // Make the asynchronous request
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Upload failed: " + e.getMessage());
                    finish(); // Close the app on failure
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            JSONObject jsonObject = new JSONObject(responseBody);
                            String url = jsonObject.getString("url");

                            // Copy the URL to the clipboard
                            copyToClipboard(url);
                            Log.i(TAG, "Upload successful: " + url);
                        } catch (JSONException e) {
                            Log.e(TAG, "Failed to parse response JSON: " + e.getMessage());
                        }
                    } else {
                        Log.e(TAG, "Upload failed: " + response.message());
                    }
                    finish(); // Close the app after handling the response
                }
            });
        } catch (IOException e) {
            Log.e(TAG, "Error uploading screenshot: " + e.getMessage());
            finish(); // Close the app on error
        }
    }

    private String generateFileName() {
        // Generate the filename in the format "android_screenshot_%Y-%m-%d.png"
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        return "android_screenshot_" + timeStamp + ".png";
    }

    private void copyToClipboard(String text) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("uploaded_url", text);
        clipboard.setPrimaryClip(clip);
    }
}
